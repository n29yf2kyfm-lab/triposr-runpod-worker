"""Strip Bay rigger — the conversion itself. One car in, one rigged car out.

`convert(objects, rep)` works on the objects ONE glTF import created and on
nothing else, so it is safe inside an artist's open scene. It returns
`(parts, hinge)` and fills `rep` with every decision it made; it raises
`Refused` rather than guess. `process_file()` wraps it with import/export for
the batch runner and the command line.

Output nodes are named `SB_<partId>__<n>` in Strip Bay's frame (+Y up, NOSE +Z,
car's LEFT +X, ground Y=0 — in glTF terms; Blender shows the same car Z-up).

WHAT THE NAMES ARE TRUSTED FOR, AND WHAT THEY ARE NOT.
A name is trusted to say WHAT a part is — "this is a door", "this is the
bonnet". It is NOT trusted to say WHICH door: corners come from where the part
SITS after the frame is fixed. Every family spells corners differently (FL,
lf, dside_f, front_left, L1) and some rigs mirror them; position cannot be
misspelt. The same goes for wheels.

FAMILIES this was written against, all measured in the catalogue:
  game rig    skinned, one bone per part (Audi A6, Peugeot 308/508, M235i).
              Baked first: each mesh follows ONE bone at weight 1.0, so the
              skin carries no deformation and applying it changes nothing.
  sim-mod     `xc90_door_FL`, `hood`, `trunk`, `tailgate` (XC90, Panamera,
              Rolls-Royce Ghost, Fiat Tipo, CLS...).
  GTA-style   `door_lf_dummy` > `door_lf_ok`, `bonnet_dummy`, `boot_dummy`,
              with `_dam` damage twins that MUST be dropped or they z-fight
              with the good panels (Superb, Amarok, Micra...).

REFUSES rather than shipping a car whose teardown would silently not work:
no doors, not four road wheels, wheels above the glass, or a frame it cannot
decide.

WELDED DOORS (2026-10-06): a car whose doors are part of its body shell is no
longer refused outright. `_cut_doors` cuts the door skins out along the car's
own shut lines (a groove, or the edge of a separate panel), grows each skin to
its panel edges, and gates every door: one that cannot be cut cleanly stays
shut, together with its twin. See its docstring for what it measures.
"""
import bpy, bmesh, json, re, math, os
from mathutils import Vector, Matrix

VERSION = '1.0.0'


class Refused(Exception):
    """The car cannot be rigged safely. The message says why."""


# ── helpers ─────────────────────────────────────────────────────────────
def G(v):
    """Blender (x, y, z) Z-up  ->  glTF (x, z, -y) Y-up."""
    return Vector((v.x, v.z, -v.y))


def B(v):
    """glTF (x, y, z) Y-up  ->  Blender (x, -z, y) Z-up."""
    return Vector((v[0], -v[2], v[1]))


def wv(o):
    return [G(o.matrix_world @ v.co) for v in o.data.vertices]


def bbox(vs):
    return (Vector((min(v.x for v in vs), min(v.y for v in vs), min(v.z for v in vs))),
            Vector((max(v.x for v in vs), max(v.y for v in vs), max(v.z for v in vs))))


def centre(os_):
    vs = [v for o in os_ for v in wv(o)]
    return sum(vs, Vector()) / len(vs)


# ── what each mesh is, from its name chain (nearest name wins) ──────────
RULES = [
    ('steering', r'steer'),
    ('door',     r'(^|[^a-z])door(?!_?(mirror|handle_int|light_int|seal_body|frame_body|jamb|sill|step|trim_body|opening))|doorf|doorr|door_?[lr][fr]'),
    # no word boundary before hood: variants are GLUED (`carbonhood`), and a
    # variant left behind z-fights under the one that lifts (BMW M6)
    ('bonnet',   r'(hood|bonnet)(?!_?(piston|strut|latch|ornament|release|prop|scoop_body|vent_body|ie))'),
    # not a LAMP on the lid: the 2026 308's `Trunk_Light` was taken as its
    # tailgate and the slider moved nothing (`light_body` alone was excluded)
    ('tailgate', r'(^|[^a-z])(trunk|tailgate|hatch|bootlid|boot)(?!_?(divider|floor|panel|carpet|cam|liner|light|lamp|lens|piston|strut|latch))'),
    # BEFORE wheel: a caliper stays bolted to the hub when the wheel comes
    # off, so it is neither wheel nor door. The RS6's rear calipers sit outside
    # the wheel hierarchy and were carried off by the rear DOORS.
    ('brakes',   r'call?iper|brake_?disc|(^|[^a-z])rotor([^a-z]|$)'),
    ('wheel',    r'(^|[^a-z])(wheel|tyre|tire|rim)(?!_?(arch|house|well|cover|liner|trim_body|lip_body))'
                 # abbreviated corners: `wfl_0`, `wrr_3` (Mercedes Vito), `whl_fl`
                 r'|(^|[^a-z])(w[fr][lr]|whl)([^a-z]|$)'),
    # lamps BEFORE glazing, or `headlight_glass` becomes a window
    ('lamps_front', r'headl|foglight|extralight|(^|[^a-z])drl'),
    ('lamps_rear',  r'taill|brakel|reversingl|rearlight'),
    ('glazing',  r'windscreen|windshield|glass|window|vitre|(^|[^a-z])glaz'),
    # NOT `chassis`: a GTA-style car's `chassis` is its whole BODY SHELL, while
    # a game rig's is the floor and cabin. It means nothing reliable.
    ('cabin',    r'interior|seat|dash|carpet|console|headlin|pedal|gauge|speedo'),
    ('engine',   r'engine|engbay|intake|turbo|intercooler|radiator|airbox'),
]
RULES = [(k, re.compile(p, re.I)) for k, p in RULES]
DOOR_RX = dict(RULES)['door']
SHIFTER_BOOT = re.compile(r'shifter_?boot|gear_?boot|gaiter', re.I)
DROP = re.compile(r'(_dam\b|_dam[_.\d]|_vlo\b|_vlo[_.]|\blod[1-9]\b|_lod[1-9]|shadow|_l[12]_end|collision|\bcol_)', re.I)
# default primitives left in the export — the A6 carries an `Icosphere`
# 0.7 m BELOW its own tyres that read as part of the car
PRIM = re.compile(r'^(icosphere|uv ?sphere|sphere|cube|plane|cylinder|cone|torus)(\.\d+)?$', re.I)
SLIDE_NAME = re.compile(r'slid', re.I)
FRONT_RX = re.compile(r'(^|[^a-z])front([^a-z]|$)', re.I)
REAR_RX = re.compile(r'(^|[^a-z])(rear|back)([^a-z]|$)', re.I)


def _chain(o):
    out = []
    if 'sb_bone' in o:
        out.append(o['sb_bone'])
    n = o
    while n is not None:
        out.append(n.name)
        n = n.parent
    return out


def _kind(o):
    for n in o['sb_chain'].split('|'):
        if SHIFTER_BOOT.search(n):
            return 'cabin'
        for k, rx in RULES:
            if rx.search(n):
                return k
    return 'body'


def _select_only(objs):
    """Select exactly `objs` and make the first active. Operators like mesh
    separate and the glTF exporter read the REAL selection, not an override."""
    vl = bpy.context.view_layer
    for o in vl.objects:
        if o is not None and o.select_get():
            o.select_set(False)
    for o in objs:
        o.select_set(True)
    vl.objects.active = objs[0]


def _remove(objs):
    for o in objs:
        try:
            bpy.data.objects.remove(o, do_unlink=True)
        except ReferenceError:
            pass


# ═════════════════════════════════════════════════════════════════════════
def convert(imported, rep, override=None):
    """Rig the objects one import created. Returns (parts, hinge).

    `imported` is the list of objects the glTF import added. Nothing outside
    it is read, moved or deleted.
    """
    imported = list(imported)

    # ── 0. BAKE any rigid skin (game rigs) ─────────────────────────────
    baked = 0
    for o in imported:
        if o.type != 'MESH':
            continue
        mods = [m for m in o.modifiers if m.type == 'ARMATURE']
        if not mods:
            continue
        used = {}
        for v in o.data.vertices:
            for g in v.groups:
                if g.weight > 0:
                    n = o.vertex_groups[g.group].name
                    used[n] = used.get(n, 0) + 1
        if len(used) > 1:
            raise Refused(f'{o.name} is skinned to {len(used)} bones — a deforming rig, not a parts rig')
        _select_only([o])
        for m in mods:
            bpy.ops.object.modifier_apply(modifier=m.name)
        o.vertex_groups.clear()
        if used:
            o['sb_bone'] = next(iter(used))        # the part is the BONE, not the mesh
        baked += 1
    rep['baked'] = baked

    # ── 1. DROP what must not render ───────────────────────────────────
    dropped = [o for o in imported if o.type == 'MESH'
               and (any(DROP.search(n) for n in _chain(o)[:3]) or PRIM.match(o.name))]
    rep['dropped'] = len(dropped)
    # the keep-list is taken BEFORE deleting: touching a removed object
    # afterwards raises ReferenceError
    imported = [o for o in imported if o not in dropped]
    _remove(dropped)

    # flatten: every mesh keeps its world pose, then the rig goes
    for o in imported:
        o['sb_chain'] = '|'.join(_chain(o))
    for o in imported:
        if o.type == 'MESH' and o.parent is not None:
            mw = o.matrix_world.copy()
            o.parent = None
            o.matrix_world = mw
    objs = [o for o in imported if o.type == 'MESH' and len(o.data.vertices)]
    _remove([o for o in imported if o.type != 'MESH' or not len(o.data.vertices)])
    if not objs:
        raise Refused('no geometry')
    K = {o: _kind(o) for o in objs}

    # ── 2. FRAME: length along Z, nose +Z, up +Y, left +X, ground 0 ────
    lo, hi = bbox([v for o in objs for v in wv(o)])
    if (hi.x - lo.x) > (hi.z - lo.z):               # length lies on X: turn 90
        Rz = Matrix.Rotation(math.radians(90), 4, 'Z')
        for o in objs:
            o.matrix_world = Rz @ o.matrix_world
        bpy.context.view_layer.update()
        rep['turn90'] = True
    wheels = [o for o in objs if K[o] == 'wheel']
    if not wheels:
        # Most "no wheels named" cars DO have wheels: the export named the
        # pieces after their MATERIAL (`Object_21` carrying `Rubber_Rough`,
        # `tire`, `Carro_Pneu`, `llanta`), so read the materials instead.
        # Only reached when the names found nothing, so a car that rigs by
        # name today cannot change.
        _material_wheels(objs, K, rep)
        wheels = [o for o in objs if K[o] == 'wheel']
    glass = [o for o in objs if K[o] == 'glazing']
    if not wheels:
        raise Refused('no wheels named')
    if glass and centre(wheels).y > centre(glass).y:
        raise Refused('wheels sit ABOVE the glass — upside down')
    cues = {}
    bon = [o for o in objs if K[o] == 'bonnet']
    tg = [o for o in objs if K[o] == 'tailgate']
    st = [o for o in objs if K[o] == 'steering']
    lo, hi = bbox([v for o in objs for v in wv(o)])
    mid = (lo + hi) / 2
    if bon and tg:
        cues['bonnet_vs_boot'] = 1 if centre(bon).z > centre(tg).z else -1
    if st:
        cues['steering'] = 1 if centre(st).z > mid.z else -1
    hl = [o for o in objs if K[o] == 'lamps_front']
    tl = [o for o in objs if K[o] == 'lamps_rear']
    if hl and tl:
        cues['head_vs_tail_lamps'] = 1 if centre(hl).z > centre(tl).z else -1
    # the WHEELS' own names, when they say front/rear ("3DWheel Front L",
    # "Calliper Rear R" on the Forza-family RS6). Trusted for which AXLE is
    # the front, never for which corner — corners still come from position.
    wf = [o for o in wheels if FRONT_RX.search(o['sb_chain']) and not REAR_RX.search(o['sb_chain'])]
    wr = [o for o in wheels if REAR_RX.search(o['sb_chain']) and not FRONT_RX.search(o['sb_chain'])]
    if wf and wr:
        cues['wheel_names'] = 1 if centre(wf).z > centre(wr).z else -1
    if not cues:
        rl = _red_lamp_end(objs, lo, hi)
        if rl:
            cues['red_tail_lamps'] = -rl            # the red end is the BACK, so the nose is the other end
            rep['red_tail_lamps'] = rl
    if not cues:
        raise Refused('cannot decide the nose: no bonnet/boot pair, no lamps, no front/rear wheel names '
                      'and no steering wheel')
    # PRIORITY, not a vote. The steering wheel is the WEAKEST cue: it sits
    # BEHIND the midpoint on a long-bonnet coupe (the GR Supra). The two ends
    # of the car outrank it, and must not contradict each other.
    ends = [cues[k] for k in ('bonnet_vs_boot', 'head_vs_tail_lamps', 'wheel_names', 'red_tail_lamps') if k in cues]
    if len(set(ends)) > 1:
        raise Refused(f'the two end cues disagree: {cues}')
    nose = ends[0] if ends else cues['steering']
    if len(set(cues.values())) > 1:
        rep['nose_overruled'] = cues
    if nose < 0:
        R180 = Matrix.Rotation(math.pi, 4, 'Z')
        for o in objs:
            o.matrix_world = R180 @ o.matrix_world
        bpy.context.view_layer.update()
    # SCALE. A quarter of the catalogue is modelled at ~0.05 units long, and
    # every rule below (wheel shape, door spacing, the app's 0.85 m wheel pull)
    # is in metres. A car outside 2.5-7.5 long is rescaled so its wheels are
    # 0.68 m tall — a typical road wheel. That puts it within a few per cent of
    # real size; it does NOT claim the car's real dimensions.
    lo, hi = bbox([v for o in objs for v in wv(o)])
    if not 2.5 <= hi.z - lo.z <= 7.5:
        wvs = [v for o in wheels for v in wv(o)]
        wh = max(v.y for v in wvs) - min(v.y for v in wvs)
        if wh <= 0:
            raise Refused('cannot size the car: the wheels have no height')
        f = 0.68 / wh
        S = Matrix.Scale(f, 4)
        for o in objs:
            o.matrix_world = S @ o.matrix_world
        bpy.context.view_layer.update()
        rep['rescaled'] = {'factor': round(f, 4), 'length_before': round(hi.z - lo.z, 4),
                           'why': 'not metre scale; wheels set to 0.68 m tall (typical, not measured)'}
    ground = min(v.y for o in wheels for v in wv(o))
    # CENTRE ACROSS THE CAR when the file is off-centre. Left and right are
    # decided by the sign of x everywhere below, so a car modelled 0.3 m to
    # one side (the Model Y, the Corolla) put all four wheels on the "left".
    # Centred by the wheels, not the bounding box, which mirrors widen; and
    # only past 2% of the width, so a car that rigs today is not moved at all.
    wx = [v.x for o in wheels for v in wv(o)]
    dx = -(min(wx) + max(wx)) / 2
    lo0, hi0 = bbox([v for o in objs for v in wv(o)])
    if abs(dx) <= .02 * (hi0.x - lo0.x):
        dx = 0.0
    else:
        rep['centred_across'] = round(dx, 4)
    T = Matrix.Translation((dx, 0, -ground))        # glTF x is Blender x
    for o in objs:
        o.matrix_world = T @ o.matrix_world
    bpy.context.view_layer.update()
    lo, hi = bbox([v for o in objs for v in wv(o)])
    mid = (lo + hi) / 2
    rep['frame'] = {'nose_cues': cues, 'yaw180': nose < 0, 'ground_shift': round(-ground, 4),
                    'extent': [round(hi.x - lo.x, 3), round(hi.y - lo.y, 3), round(hi.z - lo.z, 3)]}
    if st:
        rep['frame']['drive'] = 'LHD' if centre(st).x > 0 else 'RHD'

    # ── 2b. MIRRORED PAIRS saved as ONE mesh ───────────────────────────
    # Some exports keep both front tyres in one mesh, both rear brakes in
    # another, and both front door skins in a third (the 2022 Tiguan: all
    # three). Corners are decided per OBJECT, so a pair centred on the car's
    # middle could never fill a corner ("wheels do not fill four corners").
    split = _split_pairs(objs, K, hi.x - lo.x)
    if split:
        rep['split_pairs'] = split
        wheels = [o for o in objs if K[o] == 'wheel']

    # ── 3. CORNERS by position ─────────────────────────────────────────
    parts = {}

    def put(pid, o):
        parts.setdefault(pid, []).append(o)

    if not any(K[o] == 'door' for o in objs):
        for o in _find_doors(objs, K, wheels, lo, hi, rep):
            objs.append(o)
            K[o] = 'door'
    doorkey = {}
    for o in objs:
        if K[o] != 'door':
            continue
        root = next(n for n in o['sb_chain'].split('|') if DOOR_RX.search(n))
        root = re.sub(r'(_ok|_dummy|__\d+|\.\d+|_\d+)$', '', root, flags=re.I)
        doorkey.setdefault(root, []).append(o)
    size = lambda t: sum(len(o.data.vertices) for o in t[1])
    DOOR = {}
    L, W = hi.z - lo.z, hi.x - lo.x
    # A SIDE-door group whose pieces sit on BOTH flanks is two doors under
    # one name (the Tiguan's `lf_door` holds both front skins once its mesh
    # is split): grouped as one, its centre lands on the middle of the car
    # and both skins swing as one. Split it by flank. Groups at the back are
    # left alone — a tailgate or barn-door pair is decided below as before.
    for root in list(doorkey):
        os_ = doorkey[root]
        if centre(os_).z < lo.z + .15 * L:
            continue
        xs = [centre([o]).x for o in os_]
        if max(xs) > .15 * W and min(xs) < -.15 * W:
            del doorkey[root]
            for o, x in zip(os_, xs):
                doorkey.setdefault((root, 'l' if x > 0 else 'r'), []).append(o)
    for os_ in doorkey.values():
        c = centre(os_)
        b0, b1 = bbox([v for o in os_ for v in wv(o)])
        # A door across the BACK of a van runs sideways, not lengthways: the
        # Vito's `door_rear_left/right` are barn doors, and assigning them by
        # position made them rear SIDE doors that swung through the body.
        if c.z < lo.z + .15 * L and (b1.z - b0.z) < .5 * (b1.x - b0.x):
            if abs(c.x) < .15 * W:                  # one full-width door = tailgate
                for o in os_:
                    put('tailgate', o)
            else:
                for o in os_:
                    put('door_b' + ('l' if c.x > 0 else 'r'), o)
            continue
        DOOR.setdefault('l' if c.x > 0 else 'r', []).append((c.z, os_))
    for side, lst in DOOR.items():
        lst.sort(key=lambda t: -t[0])
        biggest = max(size(t) for t in lst)
        # ANCHORS ARE THE TWO LARGEST clusters, not the two most forward: on
        # the BMW M6 a door-glass cluster took the second anchor slot and the
        # rear door was merged into the front — both swung as one 2 m panel.
        bysize = sorted(lst, key=size, reverse=True)
        anchors = [bysize[0][0]]
        for t in bysize[1:]:
            if size(t) > 0.35 * biggest and abs(t[0] - anchors[0]) > 0.35:
                anchors.append(t[0])
                break
        anchors.sort(reverse=True)
        for z, os_ in lst:
            k = min(range(len(anchors)), key=lambda i: abs(anchors[i] - z))
            for o in os_:
                put(f"door_{'fr'[k]}{side}", o)
    nd = sum(1 for k in parts if k.startswith('door_') and k[5] in 'fr')
    if nd < 2:
        # WELDED: the doors are part of the body shell. Cut them out.
        for pid, os_ in _cut_doors(objs, K, wheels, lo, hi, rep).items():
            for o in os_:
                objs.append(o)
                K[o] = 'door'
                put(pid, o)
        nd = sum(1 for k in parts if k.startswith('door_') and k[5] in 'fr')
    if nd < 2:
        raise Refused(f'only {nd} door part(s) found — the doors are not separate objects in this file')

    # A WHEEL MUST BE WHEEL-SHAPED. On the Rolls-Royce Ghost, parts NAMED for
    # the wheel but reaching 1.6 m put its measured front track at 0.91 m.
    def shape_ok(o):
        b0, b1 = bbox(wv(o))
        h, l, w = b1.y - b0.y, b1.z - b0.z, b1.x - b0.x
        return .35 < h < 1.0 and .75 < l / max(h, 1e-6) < 1.3 and w < .65 * h
    prim = [o for o in wheels if shape_ok(o)]
    boxes = [bbox(wv(o)) for o in prim]
    rest = []
    for o in wheels:
        if o in prim:
            continue
        b0, b1 = bbox(wv(o))
        c = (b0 + b1) / 2
        inside = any(all(pb0[i] - .03 <= c[i] <= pb1[i] + .03 for i in range(3))
                     and (b1 - b0).length < (pb1 - pb0).length for pb0, pb1 in boxes)
        (prim if inside else rest).append(o)
    for o in prim:
        c = centre([o])
        put('wheel_' + ('f' if c.z > mid.z else 'r') + ('l' if c.x > 0 else 'r'), o)
    # A wheel-NAMED piece that is not wheel-shaped on its own (a caliper, one
    # rim-lip fragment) still belongs to the wheel it sits on. On the RS6 the
    # red caliper pieces sat right at the wheel's edge, fell back to "body",
    # and were then carried off by the rear DOOR. Rule: within 1.15 wheel radii
    # of a corner's centre (side view) and on its side of the car -> that wheel.
    hubs = {}
    for k in [k for k in parts if k.startswith('wheel_')]:
        b0, b1 = bbox([v for o in parts[k] for v in wv(o)])
        hubs[k] = ((b0 + b1) / 2, (b1.y - b0.y) / 2)
    joined = 0
    for o in list(rest):
        c = centre([o])
        best = None
        for k, (hc, R) in hubs.items():
            d = ((c.y - hc.y) ** 2 + (c.z - hc.z) ** 2) ** .5
            if d < 1.15 * R and abs(c.x - hc.x) < R and (best is None or d < best[1]):
                best = (k, d)
        if best:
            put(best[0], o)
            rest.remove(o)
            joined += 1
    rep['wheel_pieces_joined'] = joined
    rep['wheel_rejects'] = [o['sb_chain'][:50] for o in rest][:8]
    for o in rest:
        K[o] = 'body'
    got = sorted(k for k in parts if k.startswith('wheel_'))
    if got != ['wheel_fl', 'wheel_fr', 'wheel_rl', 'wheel_rr']:
        rep['wheel_shapes'] = []                   # why each candidate failed the wheel-shape test
        for o in wheels:
            b0, b1 = bbox(wv(o))
            rep['wheel_shapes'].append({'part': o['sb_chain'][:40], 'h': round(b1.y - b0.y, 3),
                                        'l': round(b1.z - b0.z, 3), 'w': round(b1.x - b0.x, 3)})
        raise Refused(f'wheels do not fill four corners ({got}) — often ONE wheel the game copies at run time')
    for o in objs:
        if K[o] in ('door', 'wheel') or any(o in v for v in parts.values()):
            continue
        put({'bonnet': 'panel_bonnet'}.get(K[o], K[o]), o)

    # glass and handles INSIDE a door's box travel with the door
    for pid in [k for k in parts if k.startswith('door_')]:
        b0, b1 = bbox([v for o in parts[pid] for v in wv(o)])
        for other in ('glazing', 'body'):
            keep = []
            for o in parts.get(other, []):
                ov = wv(o)
                if not ov:                  # a mesh left with no vertices (3 catalogue cars crashed here)
                    keep.append(o)
                    continue
                ob0, ob1 = bbox(ov)
                inside = all(b0[i] - .02 <= ob0[i] and ob1[i] <= b1[i] + .02 for i in range(3))
                (parts[pid] if inside else keep).append(o)
            if other in parts:
                parts[other] = keep

    if rep.get('door_finder', {}).get('doors') or rep.get('door_cutter', {}).get('faces'):
        _adopt_into_doors(parts, rep)       # handles, door cards: loose pieces inside the door

    # ── 4. TYRES MUST READ AS BLACK RUBBER ─────────────────────────────
    rep['tyre_faces_to_rubber'] = _rubber_tyres(parts)

    # ── 5. PAINT: the material covering most of the bonnet (or doors) ──
    paint = _paint(parts, rep)

    # ── 6. BONNET / BOOT from the paint mesh if no part carries them ───
    _lift_panels(parts, paint, lo, hi, rep)
    rep['missing'] = [p for p in _wanted(parts) if not parts.get(p)]

    # ── 7. HINGES, and which doors SLIDE ───────────────────────────────
    hinge = _hinges(parts, bool(rep.get('door_finder', {}).get('doors') or rep.get('door_cutter', {}).get('faces')))
    dropped = _implausible(parts, hinge)
    if dropped:
        rep['implausible'] = dropped
        # What was taken for the doors was not (the Polo's "doors" were its
        # wings). If no side door is left, cut the real ones from the body.
        if not any(k in parts for k in ('door_fl', 'door_fr', 'door_rl', 'door_rr')) \
                and any(d.startswith('door_') and 'kept' not in d for d in dropped) and 'door_cutter' not in rep:
            pool = parts.get('body', []) + parts.get('glazing', [])
            kk = {o: ('glazing' if o in parts.get('glazing', []) else 'body') for o in pool}
            cut = _cut_doors(pool, kk, [o for k in parts if k.startswith('wheel_') for o in parts[k]], lo, hi, rep)
            for pid, os_ in cut.items():
                parts[pid] = os_
            if cut:
                _adopt_into_doors(parts, rep)
                for pid, h in _hinges(parts, True).items():
                    if pid in cut:
                        hinge[pid] = h
                again = _implausible(parts, {k: v for k, v in hinge.items() if k in cut})
                for d in again:
                    if 'kept' not in d:
                        hinge.pop(d.split(':')[0], None)
                rep['implausible'] += again
        rep['missing'] = [p for p in _wanted(parts) if not parts.get(p)]
    rep['hinge'] = hinge
    rep['motion'] = _motion(parts, hi.y - lo.y, rep, override)

    # ── 8. GLASS: say what the file claims, the render decides ─────────
    gm = {}
    for o in parts.get('glazing', []) + [o for k in parts if k.startswith('door_') for o in parts[k]]:
        for s in o.material_slots:
            m = s.material
            if m and re.search(r'glass|window|vitre|screen', m.name, re.I):
                gm[m.name] = getattr(m, 'blend_method', '?')
    rep['glass_materials'] = gm

    # ── 9. NAME ────────────────────────────────────────────────────────
    for pid, os_ in parts.items():
        for k, o in enumerate(os_):
            o.name = f'SB_{pid}__{k}'
            o.data.name = o.name
            o['sb_part'] = pid
    rep['parts'] = {k: len(v) for k, v in sorted(parts.items())}
    return parts, hinge


# ═════════════════════════════════════════════════════════════════════════
def _rubber_tyres(parts):
    """Owner ruling 2026-08-09: tyres read as black rubber. On sim-mod cars the
    tyre is often the RIM's material (Captur: `wheel_rim`, grey metal 0.56).
    Split by radius PER TRIANGLE: a face is tyre if it reaches the tread band
    and none of its corners come in to the rim. Only LIGHT, UNTEXTURED faces
    are touched, so a correct black or textured tyre is left alone."""
    rubber = bpy.data.materials.get('SB_tyre_rubber') or bpy.data.materials.new('SB_tyre_rubber')
    rubber.use_nodes = True
    b = rubber.node_tree.nodes.get('Principled BSDF')
    b.inputs['Base Color'].default_value = (0.022, 0.022, 0.024, 1)
    b.inputs['Roughness'].default_value = 0.88
    b.inputs['Metallic'].default_value = 0.0

    def light_untextured(m):
        if m is None or not m.use_nodes:
            return False
        n = m.node_tree.nodes.get('Principled BSDF')
        if n is None or n.inputs['Base Color'].is_linked:
            return False
        c = n.inputs['Base Color'].default_value
        return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2] > 0.18

    done, split = set(), 0
    for k in [k for k in parts if k.startswith('wheel_')]:
        b0, b1 = bbox([v for o in parts[k] for v in wv(o)])
        cy, cz, R = (b0.y + b1.y) / 2, (b0.z + b1.z) / 2, (b1.y - b0.y) / 2
        for o in parts[k]:
            if o.data.name in done or not any(light_untextured(s.material) for s in o.material_slots):
                continue
            mw, hits = o.matrix_world, []
            for p in o.data.polygons:
                if p.material_index >= len(o.material_slots):
                    continue
                if not light_untextured(o.material_slots[p.material_index].material):
                    continue
                rr = [((q.y - cy) ** 2 + (q.z - cz) ** 2) ** .5
                      for q in (G(mw @ o.data.vertices[vi].co) for vi in p.vertices)]
                if max(rr) > 0.85 * R and min(rr) > 0.60 * R:
                    hits.append(p.index)
            if not hits:
                continue
            o.data.materials.append(rubber)
            ri = len(o.data.materials) - 1
            for i in hits:
                o.data.polygons[i].material_index = ri
            done.add(o.data.name)
            split += len(hits)
    return split


def _paint(parts, rep):
    """The paint is the material on the OUTSIDE of the panel. Counting all area
    picked the Sharan's black door CARD (the door is two skins, and the inner
    one carries more trim); counting only faces that face outward — up for a
    bonnet, away from the centreline for a door — picks the skin."""
    def mat_area(os_, outward):
        A = {}
        for o in os_:
            sc = o.matrix_world.to_scale()
            s = abs(sc.x * sc.y * sc.z) ** (2 / 3)
            n3 = o.matrix_world.to_3x3()
            for p in o.data.polygons:
                if p.material_index < len(o.material_slots) and o.material_slots[p.material_index].material:
                    n = G(n3 @ p.normal)
                    if n.length == 0 or outward(n.normalized()) < 0.5:
                        continue
                    m = o.material_slots[p.material_index].material
                    A[m] = A.get(m, 0) + p.area * s
        return A
    if parts.get('panel_bonnet'):
        A = mat_area(parts['panel_bonnet'], lambda n: n.y)
    else:
        A = {}
        for k in [k for k in parts if k.startswith('door_') and k[5] in 'fr']:
            sx = 1 if k[-1] == 'l' else -1
            for m, a in mat_area(parts[k], lambda n, sx=sx: n.x * sx).items():
                A[m] = A.get(m, 0) + a
    if not A:
        return None
    paint = max(A, key=A.get)
    rep['paint'] = {'material': paint.name, 'from': 'bonnet' if parts.get('panel_bonnet') else 'doors',
                    'share': round(A[paint] / sum(A.values()), 3)}
    # SIBLINGS ARE THE SAME PAINT: the Micra's bonnet is `primary.001` and its
    # body `primary`. Blender's `.NNN` suffix is an import artefact.
    base = re.sub(r'\.\d+$', '', paint.name)
    sib = [m for m in bpy.data.materials if re.sub(r'\.\d+$', '', m.name) == base]
    for m in sib:
        if 'paint' not in m.name.lower():
            m.name = m.name + '_paint'              # the app finds paint by this word
    rep['paint']['renamed'] = [m.name for m in sib]
    return paint


def _islands(o):
    bm = bmesh.new()
    bm.from_mesh(o.data)
    bm.faces.ensure_lookup_table()
    tag = bm.faces.layers.int.new('orig')
    for f in bm.faces:
        f[tag] = f.index
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-5)   # weld for ISLANDS only
    bm.faces.ensure_lookup_table()
    seen, comps = set(), []
    mw = o.matrix_world
    n3 = mw.to_3x3()
    for f in bm.faces:
        if f.index in seen:
            continue
        stk, comp = [f], []
        seen.add(f.index)
        while stk:
            g = stk.pop()
            comp.append(g)
            for e in g.edges:
                for h in e.link_faces:
                    if h.index not in seen:
                        seen.add(h.index)
                        stk.append(h)
        vs = [G(mw @ v.co) for g in comp for v in g.verts]
        area = sum(g.calc_area() for g in comp)
        ns = [(G(n3 @ g.normal), g.calc_area()) for g in comp]
        up = sum(n.y * a for n, a in ns) / max(area, 1e-9)
        fwd = sum(n.z * a for n, a in ns) / max(area, 1e-9)
        # a panel modelled with THICKNESS is a closed shell whose top and
        # bottom normals cancel (the RS6's bonnet reads mean-up 0.0), so also
        # keep the share of area that is horizontal / faces along the car
        upf = sum(a for n, a in ns if n.length and abs(n.normalized().y) > .55) / max(area, 1e-9)
        endf = sum(a for n, a in ns if n.length and abs(n.normalized().z) > .55) / max(area, 1e-9)
        comps.append((bbox(vs), up, [g[tag] for g in comp], fwd, area, upf, endf))
    bm.free()
    return comps


def _lift(o, fidx):
    """Separate the faces `fidx` (ORIGINAL indices) off `o` into a new object.
    Indices are stamped into an attribute first, because a separation
    renumbers every face after it."""
    att = o.data.attributes.new('sb_lift', 'INT', 'FACE')
    for i in fidx:
        att.data[i].value = 1
    before = set(bpy.data.objects)
    _select_only([o])
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_mode(type='FACE')
    bpy.ops.mesh.select_all(action='DESELECT')
    ebm = bmesh.from_edit_mesh(o.data)
    lay = ebm.faces.layers.int['sb_lift']
    for f in ebm.faces:
        if f[lay] == 1:
            f.select_set(True)
    ebm.select_flush_mode()
    bmesh.update_edit_mesh(o.data)
    bpy.ops.mesh.separate(type='SELECTED')
    bpy.ops.object.mode_set(mode='OBJECT')
    new = [x for x in bpy.data.objects if x not in before][0]
    for ob in (o, new):
        if 'sb_lift' in ob.data.attributes:
            ob.data.attributes.remove(ob.data.attributes['sb_lift'])
    return new


WHEEL_MAT = re.compile(r'tyre|tire|rubber|pneu|reifen|llanta|luntai|lungu|wheel|felge|rueda'
                       r'|(^|[^a-z])rim([^a-z]|$)|(^|_)rin(_|\d|$)', re.I)


def _material_wheels(objs, K, rep):
    """Find the four wheels from MATERIAL names and position, for exports that
    name every piece after its material. Takes the faces whose material reads
    as tyre / rim / wheel, keeps those in the lower 45% of the car and away
    from its centreline (no steering wheel, no spare in the boot floor's
    middle), splits them into the four corners and lifts each corner into one
    object. Refuses silently (finds nothing) unless all four corners have a
    real share of faces. Returns what it did."""
    bpy.context.view_layer.update()            # the drop step left stale view-layer entries
    lo, hi = bbox([v for o in objs for v in wv(o)])
    H, W = hi.y - lo.y, hi.x - lo.x
    xm, zm = (lo.x + hi.x) / 2, (lo.z + hi.z) / 2
    plan, cand = {}, {}
    for o in objs:
        if K[o] in ('wheel', 'glazing', 'lamps_front', 'lamps_rear', 'cabin', 'steering'):
            continue
        hit = {i for i, s in enumerate(o.material_slots) if s.material and WHEEL_MAT.search(s.material.name)}
        if not hit:
            continue
        mw = o.matrix_world
        vs = [G(mw @ v.co) for v in o.data.vertices]
        for p in o.data.polygons:
            if p.material_index not in hit:
                continue
            c = sum((vs[i] for i in p.vertices), Vector()) / len(p.vertices)
            if c.y > lo.y + .45 * H or abs(c.x - xm) < .12 * W:
                continue
            q = ('f' if c.z > zm else 'r') + ('l' if c.x > xm else 'r')
            cand.setdefault(q, []).append((o, p.index, c))
    # A rim or tyre MATERIAL often also covers the axle, the hub carrier or
    # brake hardware (A3, Model Y, Corolla: corners came out twice as long as
    # they were tall). Keep only what sits ON the wheel: inside its circle in
    # side view, and within a wheel-width of the outside of the car.
    for q, fs in cand.items():
        ys = sorted(f[2].y for f in fs)
        y0, y1 = ys[int(.01 * (len(ys) - 1))], ys[int(.99 * (len(ys) - 1))]
        D = max(y1 - y0, 1e-6)
        yc = y0 + D / 2
        top = sorted(f[2].z for f in fs if f[2].y > y0 + .85 * D) or sorted(f[2].z for f in fs)
        zc = top[len(top) // 2]
        xs = sorted(abs(f[2].x - xm) for f in fs)
        xout = xs[int(.99 * (len(xs) - 1))]
        for o, i, c in fs:
            if (c.z - zc) ** 2 + (c.y - yc) ** 2 <= (.56 * D) ** 2 and abs(c.x - xm) >= xout - .5 * D:
                plan.setdefault(o, {}).setdefault(q, []).append(i)
    counts = {q: sum(len(g.get(q, [])) for g in plan.values()) for q in ('fl', 'fr', 'rl', 'rr')}
    if min(counts.values()) < 24:                  # a wheel is never a handful of faces
        rep['material_wheels'] = {'found': False, 'faces_per_corner': counts}
        return
    used = sorted({s.material.name for o in plan for s in o.material_slots
                   if s.material and WHEEL_MAT.search(s.material.name)})[:8]
    byq = {}
    for o, g in plan.items():
        if o.data.users > 1:
            o.data = o.data.copy()
        qs = [q for q in ('fl', 'fr', 'rl', 'rr') if g.get(q)]
        for q, piece in zip(qs, _lift_many(o, [g[q] for q in qs])):
            piece['sb_chain'] = o['sb_chain']
            byq.setdefault(q, []).append(piece)
    for q, pieces in byq.items():
        if len(pieces) > 1:                        # one object per corner, so the shape test sees a whole wheel
            _select_only(pieces)
            bpy.ops.object.join()
        w = pieces[0]
        w['sb_chain'] = f'material_wheel_{q}|' + w['sb_chain']
        objs.append(w)
        K[w] = 'wheel'
    # the pieces a join consumed were never added to objs; drop any source
    # mesh the lift emptied completely (a tyre-only object)
    empty = [o for o in plan if not len(o.data.polygons)]
    for o in empty:
        objs.remove(o)
        K.pop(o, None)
    _remove(empty)
    bpy.context.view_layer.update()
    rep['material_wheels'] = {'found': True, 'faces_per_corner': counts, 'materials': used}


def _implausible(parts, hinge):
    """Put back into the body any opening part that cannot physically be what
    it claims, so it stays shut instead of flying off. Measured on the 2023
    Sportage (front 'doors' hinged AHEAD of the front wheels, a fifth of the
    car long, swinging into the air) and the 2023 Polo (a 'bonnet' carrying the
    wings and bumper, tearing the front apart). Returns what it dropped."""
    wc = {k: centre(parts[k]) for k in ('wheel_fl', 'wheel_fr', 'wheel_rl', 'wheel_rr') if parts.get(k)}
    if len(wc) < 4 or os.environ.get('SB_NO_IMPLAUSIBLE'):       # the switch is for A/B renders only
        return []
    allv = [v for os_ in parts.values() for o in os_ if len(o.data.vertices) for v in wv(o)]
    lo, hi = bbox(allv)
    L, H = hi.z - lo.z, hi.y - lo.y
    wtop = max(max(v.y for o in parts[k] for v in wv(o)) for k in wc)
    zf = (wc['wheel_fl'].z + wc['wheel_fr'].z) / 2
    zr = (wc['wheel_rl'].z + wc['wheel_rr'].z) / 2
    out = []
    for pid in list(hinge):
        objs_ = [o for o in parts.get(pid, []) if len(o.data.vertices)]
        if not objs_:
            continue
        b0, b1 = bbox([v for o in objs_ for v in wv(o)])
        lim = .42 * L if pid.startswith('door_') else .35 * L if pid == 'tailgate' else None
        if lim and b1.z - b0.z > lim and len(objs_) > 1:
            # TOO LONG is usually ONE stray piece grouped with a good door (the
            # Stonic, Lancer, G-class): send back to the body what lies away from
            # the part's largest piece, and judge what is left
            main = max(objs_, key=lambda o: len(o.data.vertices))
            m0, m1 = bbox(wv(main))
            # a piece belongs if it lies WITHIN the main piece's length (with a
            # margin): the Lancer's stray is a 2.8 m body-colour strip centred
            # inside the door, the Stonic's are pieces of the REAR door
            def within(o):
                o0, o1 = bbox(wv(o))
                return m0.z - .08 * L <= o0.z and o1.z <= m1.z + .08 * L
            stray = [o for o in objs_ if o is not main and not within(o)]
            rest = [o for o in objs_ if o not in stray]
            if stray and rest:
                r0, r1 = bbox([v for o in rest for v in wv(o)])
                if r1.z - r0.z <= lim:
                    parts[pid] = rest
                    # a piece of the OTHER door on this side goes to that door
                    twin = None
                    if pid.startswith('door_') and pid[5] in 'fr':
                        twin = 'door_' + ('r' if pid[5] == 'f' else 'f') + pid[6]
                    for o in stray:
                        if twin in parts and twin in hinge:
                            t0, t1 = bbox([v for x in parts[twin] for v in wv(x)])
                            o0, o1 = bbox(wv(o))
                            if t0.z - .05 * L <= o0.z and o1.z <= t1.z + .05 * L:
                                parts[twin].append(o)
                                continue
                        parts.setdefault('body', []).append(o)
                    hinge[pid] = _hinges({pid: rest}, False)[pid]
                    out.append(f'{pid}: kept; {len(stray)} stray piece(s) sent back to the body')
                    objs_, b0, b1 = rest, r0, r1
        h, why = hinge[pid], None
        wb = zf - zr
        cz = (b0.z + b1.z) / 2
        if pid.startswith('door_') and pid[5] in 'fr':
            if b1.z - b0.z > .42 * L:
                why = f'{b1.z - b0.z:.2f} long, more than 42% of the car'
            elif not zr - .05 * L <= h['z'] <= zf + .04 * L:
                # a door's hinge is behind the front axle; ahead of it is the
                # WING (the Polo's "front doors" sat right over the front wheel)
                why = 'hinged outside the wheelbase (a wing, not a door)'
            # a FRONT door hangs just behind the front axle; a REAR door on
            # the B-pillar, in the rear part of the wheelbase (the Polo's
            # "front doors" were pieces of its rear half)
            elif pid[5] == 'f' and h['z'] < zf - .45 * wb:
                why = 'a front door hinged in the rear half of the wheelbase'
            elif pid[5] == 'r' and h['z'] > zf - .2 * wb:
                why = 'a rear door hinged at the front axle'
        elif pid == 'panel_bonnet':
            # A bonnet can be a CLAMSHELL that carries the wings (Jaguar
            # F-type, 370Z) or a low front lid (Porsche 911): height and mean
            # height both rejected real ones. What a bonnet never does is
            # reach down to bumper height, which the Polo's "bonnet" did.
            if b0.y < .6 * wtop:
                why = f'reaches down to {b0.y:.2f}, bumper height — not a bonnet'
            elif cz < zf - .15 * L:
                why = 'not over the front of the car'
        elif pid == 'tailgate':
            if b1.z - b0.z > .35 * L:
                why = f'{b1.z - b0.z:.2f} long, more than 35% of the car'
            elif cz > zr + .15 * L:
                why = 'not at the back of the car'
        if why:
            parts.setdefault('body', []).extend(parts.pop(pid))
            del hinge[pid]
            out.append(f'{pid}: {why}')
    return out


def _split_pairs(objs, K, width):
    """Split a door, wheel or brake mesh that holds BOTH sides of the car into
    a left and a right object. Narrow on purpose: the mesh must reach well past
    the centreline on both sides, each side must carry at least a fifth of its
    faces, and almost nothing may cross the middle — a pair of separate pieces,
    never one part that genuinely spans the car. Returns what it split."""
    done = []
    for o in [o for o in objs if K[o] in ('door', 'wheel', 'brakes')]:
        b0, b1 = bbox(wv(o))
        if not (b0.x < -.25 * width and b1.x > .25 * width):
            continue
        if o.data.users > 1:                       # a shared mesh must not be cut for everyone
            o.data = o.data.copy()
        mw = o.matrix_world
        vx = [G(mw @ v.co).x for v in o.data.vertices]
        left, cross, n = [], 0, len(o.data.polygons)
        for p in o.data.polygons:
            xs = [vx[i] for i in p.vertices]
            if min(xs) < -.02 * width and max(xs) > .02 * width:
                cross += 1
            elif sum(xs) > 0:
                left.append(p.index)
        if not n or cross > .02 * n or not (.2 * n <= len(left) <= .8 * n):
            continue
        new = _lift(o, left)
        new['sb_chain'] = o['sb_chain']
        objs.append(new)
        K[new] = K[o]
        done.append(f'{o.name[:40]} ({K[o]})')
    # ...and a wheel object holding BOTH AXLES (the 2023 Sportage keeps all
    # four wheels in one object) is split front / rear, the same narrow way
    lo, hi = bbox([v for o in objs for v in wv(o)])
    L, zm = hi.z - lo.z, (lo.z + hi.z) / 2
    for o in [o for o in objs if K[o] == 'wheel']:
        b0, b1 = bbox(wv(o))
        if not (b0.z < zm - .2 * L and b1.z > zm + .2 * L):
            continue
        if o.data.users > 1:
            o.data = o.data.copy()
        mw = o.matrix_world
        vz = [G(mw @ v.co).z for v in o.data.vertices]
        front, cross, n = [], 0, len(o.data.polygons)
        for p in o.data.polygons:
            zs = [vz[i] for i in p.vertices]
            if min(zs) < zm < max(zs):
                cross += 1
            elif sum(zs) / len(zs) > zm:
                front.append(p.index)
        if not n or cross > .02 * n or not (.2 * n <= len(front) <= .8 * n):
            continue
        new = _lift(o, front)
        new['sb_chain'] = o['sb_chain']
        objs.append(new)
        K[new] = K[o]
        done.append(f'{o.name[:40]} (wheel, front/rear)')
    return done


RED_NAME = re.compile(r'(?<![a-z])red|red(?![a-z])|tail|lanterna|brake.?light|stop.?light|rear.?light|rueckl|feu.?arr', re.I)


def _red_lamp_end(objs, lo, hi):
    """Which end carries the red tail lamps: +1 (+Z end), -1, or None.
    A material counts as a red lamp by its NAME or its base colour, never
    the body paint (the material with the most area), so a red car does not
    paint both ends red. Only faces at lamp height in the end 15% of the
    length count, and one end must carry three times the other."""
    L, H = hi.z - lo.z, hi.y - lo.y
    area = {}
    for o in objs:
        for p in o.data.polygons:
            if o.material_slots and p.material_index < len(o.material_slots):
                m = o.material_slots[p.material_index].material
                if m:
                    area[m.name] = area.get(m.name, 0) + p.area
    paint = max(area, key=area.get) if area else None

    def red(m):
        if not m or m.name == paint:
            return False
        if RED_NAME.search(m.name):
            return True
        bs = next((n for n in (m.node_tree.nodes if m.use_nodes and m.node_tree else []) if n.type == 'BSDF_PRINCIPLED'), None)
        if bs and not bs.inputs['Base Color'].links:
            r, g, b = bs.inputs['Base Color'].default_value[:3]
            return r > .45 and g < .2 and b < .2
        return False
    end = {1: 0.0, -1: 0.0}
    for o in objs:
        reds = {i for i, s in enumerate(o.material_slots) if red(s.material)}
        if not reds:
            continue
        mw = o.matrix_world
        for p in o.data.polygons:
            if p.material_index not in reds:
                continue
            c = G(mw @ p.center)
            if not lo.y + .25 * H < c.y < lo.y + .85 * H:
                continue
            if c.z > hi.z - .15 * L:
                end[1] += p.area
            elif c.z < lo.z + .15 * L:
                end[-1] += p.area
    a, b = end[1], end[-1]
    if a > 3 * b and a > 0:
        return 1
    if b > 3 * a and b > 0:
        return -1
    return None


def _wanted(parts):
    """Panels this vehicle should have. A van closed by BARN doors has no
    tailgate: lifting one anyway cut a slab out of the Vito's rear body."""
    barn = 'door_bl' in parts or 'door_br' in parts
    return [p for p in ('panel_bonnet', 'tailgate') if not (p == 'tailgate' and barn)]


def _lift_many(o, groups):
    """Separate several face groups (ORIGINAL indices) off `o`, one new object
    per group. Every group is stamped before the first separation, because a
    separation renumbers the faces left behind."""
    att = o.data.attributes.new('sb_lift', 'INT', 'FACE')
    for gi, fidx in enumerate(groups, 1):
        for i in fidx:
            att.data[i].value = gi
    out = []
    for gi in range(1, len(groups) + 1):
        before = set(bpy.data.objects)
        _select_only([o])
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(type='FACE')
        bpy.ops.mesh.select_all(action='DESELECT')
        ebm = bmesh.from_edit_mesh(o.data)
        lay = ebm.faces.layers.int['sb_lift']
        for f in ebm.faces:
            f.select_set(f[lay] == gi)
        ebm.select_flush_mode()
        bmesh.update_edit_mesh(o.data)
        bpy.ops.mesh.separate(type='SELECTED')
        bpy.ops.object.mode_set(mode='OBJECT')
        out.append([x for x in bpy.data.objects if x not in before][0])
    for ob in [o] + out:
        if 'sb_lift' in ob.data.attributes:
            ob.data.attributes.remove(ob.data.attributes['sb_lift'])
    return out


def _shut_line(o, fidx, z0, z1):
    """Where a piece holding BOTH doors of one side splits.

    Connectivity cannot say: on the RS6 the two doors' outer skin is one
    continuous surface (edge count across the flank never drops below 84 of a
    median 90), so the shut line is a GROOVE, not a gap. What a groove leaves
    is a bunch of SHARP (>30 deg), near-VERTICAL edges. Sum their length along
    the car in 60 bins, search the middle 25-75% of the piece, and take the
    peak — only when it clearly stands out (>= 3x everything else searched).
    RS6: one peak of 3.70 at 49% of the piece, zero elsewhere in range."""
    bm = bmesh.new()
    bm.from_mesh(o.data)
    bm.faces.ensure_lookup_table()
    keep = set(fidx)
    for f in [f for f in bm.faces if f.index not in keep]:
        f.tag = True
    bmesh.ops.delete(bm, geom=[f for f in bm.faces if f.tag], context='FACES')
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-6)
    mw = o.matrix_world
    NB = 60
    hist = [0.0] * NB
    for e in bm.edges:
        if len(e.link_faces) != 2 or e.calc_face_angle(0) < math.radians(30):
            continue
        a, b = G(mw @ e.verts[0].co), G(mw @ e.verts[1].co)
        d = b - a
        if d.length == 0 or abs(d.y) / d.length < .8:
            continue
        k = min(NB - 1, max(0, int(((a.z + b.z) / 2 - z0) / (z1 - z0) * NB)))
        hist[k] += d.length
    bm.free()
    lo_k, hi_k = int(.25 * NB), int(.75 * NB)
    k = max(range(lo_k, hi_k), key=lambda i: hist[i])
    rest = [hist[i] for i in range(lo_k, hi_k) if abs(i - k) > 3]
    ref = max(rest) if rest else 0
    prof = {'peak': round(hist[k], 3), 'at_frac': round((k + .5) / NB, 3), 'next_best': round(ref, 3)}
    if hist[k] > 0 and hist[k] >= 3 * ref:
        return z0 + (k + .5) / NB * (z1 - z0), prof
    return None, prof


def _find_doors(objs, K, wheels, lo, hi, rep):
    """STEP-3 SEED: doors that are LOOSE PIECES inside a body mesh rather than
    named objects. Game rips often keep each panel as its own island inside
    one paint mesh (the Forza-family Audi RS6: the whole paint is one mesh, and
    each side's two doors are one loose piece). A door island here is: wholly
    on one flank, at least 45% of the car's height from low down, 15-60% of its
    length, centred between the axles, with a mirror-image partner on the other
    side. A piece long enough to be two doors is split at its shut line.
    Calibrated on ONE car (the RS6); refuses rather than guesses when the two
    sides disagree."""
    L, W, H = hi.z - lo.z, hi.x - lo.x, hi.y - lo.y
    cx = (lo.x + hi.x) / 2
    wz = [centre([o]).z for o in wheels]
    zf, zr = max(wz), min(wz)
    found = {'l': [], 'r': []}
    for o in objs:
        if K[o] != 'body' or len(o.data.polygons) < 50:
            continue
        for c in _islands(o):
            b0, b1 = c[0]
            side = 'l' if b0.x - cx > .25 * W else 'r' if cx - b1.x > .25 * W else None
            if not side or not (b1.y - b0.y > .45 * H and b0.y < lo.y + .35 * H):
                continue
            if not (.15 * L < b1.z - b0.z < .6 * L and zr < (b0.z + b1.z) / 2 < zf):
                continue
            found[side].append((c[4], o, c[2], b0, b1))
    info = rep.setdefault('door_finder', {})
    if not found['l'] or not found['r']:
        info['result'] = f"no door-shaped piece on {'both sides' if not (found['l'] or found['r']) else 'one side'}"
        return []
    for side in found:
        found[side].sort(key=lambda t: -t[0])
        big = found[side][0][0]
        found[side] = [t for t in found[side] if t[0] > .3 * big][:2]
    (l0, l1), (r0, r1) = [(found[sd][0][3], found[sd][0][4]) for sd in ('l', 'r')]
    if abs(l0.z - r0.z) > .05 * L or abs(l1.z - r1.z) > .05 * L:
        info['result'] = 'left and right door pieces do not mirror each other — not guessing'
        return []
    groups = {}                                   # object -> list of (name, fidx)
    for side in ('l', 'r'):
        lst = found[side]
        if len(lst) == 1 and lst[0][4].z - lst[0][3].z > .3 * L:
            area, o, fidx, b0, b1 = lst[0]
            cut, prof = _shut_line(o, fidx, b0.z, b1.z)
            info[f'shut_line_{side}'] = prof
            if cut is not None:
                bm = bmesh.new()
                bm.from_mesh(o.data)
                bm.faces.ensure_lookup_table()
                mw = o.matrix_world
                fr = [i for i in fidx if G(mw @ bm.faces[i].calc_center_median()).z > cut]
                rr = [i for i in fidx if i not in set(fr)]
                bm.free()
                info[f'split_{side}'] = {'cut_z': round(cut, 4), 'cut_frac': round((cut - lo.z) / L, 3),
                                         'front': len(fr), 'rear': len(rr)}
                groups.setdefault(o, []).extend([(f'door_island_{side}f', fr), (f'door_island_{side}r', rr)])
                continue
        for k, (area, o, fidx, b0, b1) in enumerate(lst):
            groups.setdefault(o, []).append((f'door_island_{side}{k}', fidx))
    out = []
    for o, gl in groups.items():
        for (name, _), new in zip(gl, _lift_many(o, [g for _, g in gl])):
            new.name = name
            new['sb_chain'] = name
            out.append(new)
    info['doors'] = [o.name for o in out]
    info['result'] = f'{len(out)} door piece(s) lifted from body islands'
    return out


ANG = float(os.environ.get('SB_CUT_ANG', 40))
GLASS_MAT = re.compile(r'glass|window|vitre|windscreen|windshield|lamp|light|lens|tyre|tire|rubber|chrome_?badge', re.I)


def _peak(hist, a, b, need):
    """The strongest bin in [a, b) if it clears `need`, else None."""
    a, b = max(0, a), min(len(hist), b)
    if a >= b:
        return None
    k = max(range(a, b), key=lambda i: hist[i])
    return k if hist[k] >= need else None


def _cut_doors(objs, K, wheels, lo, hi, rep):
    """WELDED DOORS: cut the door skins out of the body shell, so a car whose
    doors are part of one paint mesh still opens (owner, 2026-10-06: "if the
    doors are welded just rebuild them with the doors open").

    Only reached when no door was found by name or as a loose island.

    WHERE TO CUT, strongest evidence first:
      1. SHUT LINES. A modelled shut line is a groove, and a groove leaves a
         bunch of sharp (>30 deg) near-vertical edges. Summed along the car on
         both flanks, the Ford Focus peaks at exactly the front door's leading
         edge and the B-pillar (checked on a side render with the peaks drawn).
      2. PROPORTIONS, when the mesh has no groove (the 2023 Polo's flank has
         none): front door from 33% to 63% of the wheelbase behind the front
         axle, rear door back to 4.5% ahead of the rear axle. Calibrated on
         ONE car (the Focus, whose grooves land at 33% and 63%); a GUESSED line,
         and `rep['door_cutter']['evidence']` says so.
    Top: where the door's PAINT ends — the window surround is another
    material. Not the lowest glass: the Focus models its panes running down
    INSIDE the door, which put the "belt" 30 cm low and cut the doors in half.
    Bottom: 0.7 wheel radii up (the sill stays on the body). The arches are cut
    round, not through. Each side window goes with its door as a WHOLE pane
    (cut face by face, a pane was split at the line).

    Assumes four doors; a two-door car needs an override. Each door gets a
    dark inner card so it reads as a door, not a hollow skin, once open.
    Returns {pid: [objects]}, or {} when the cut finds too little skin."""
    info = rep.setdefault('door_cutter', {})
    L, W, H = hi.z - lo.z, hi.x - lo.x, hi.y - lo.y
    cx = (lo.x + hi.x) / 2
    wz = [centre([o]).z for o in wheels]
    zf, zr = max(wz), min(wz)
    wb = zf - zr
    r = max(v.y for o in wheels for v in wv(o)) / 2       # ground is 0
    if wb < .3 * L or r <= 0:
        info['result'] = 'cannot place the axles'
        return {}
    src = [o for o in objs if K[o] == 'body' and len(o.data.polygons) >= 50]
    gls = [o for o in objs if K[o] == 'glazing' and len(o.data.polygons)]

    def faces(o):
        mw = o.matrix_world
        n3 = mw.to_3x3().inverted().transposed()
        s = abs(mw.to_3x3().determinant()) ** (2 / 3)
        mats = [sl.material.name if sl.material else '' for sl in o.material_slots]
        for p in o.data.polygons:
            n = G(n3 @ p.normal)
            if n.length:
                n.normalize()
            yield p.index, G(mw @ p.center), n, p.area * s, mats[p.material_index] if mats else ''

    ysill = .7 * r
    ytop = hi.y - .12 * H                           # never the roof

    # shut lines: sharp, near-vertical edges on either flank between the belt and the sill
    NB, NY = 80, 6
    hist = [0.0] * NB
    hits = [[set(), set()] for _ in range(NB)]      # height bands hit, per flank
    # An OPEN edge counts too: where a panel is its own piece of mesh, the shut
    # line is its boundary, not a groove (the 2023 Polo: no groove anywhere,
    # and its shut lines are the edges of separate panels and thin dark strips).
    for o in [o for o in objs if K[o] == 'body']:
        mw = o.matrix_world
        bm = bmesh.new()
        bm.from_mesh(o.data)
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-6)
        for e in bm.edges:
            nl = len(e.link_faces)
            if nl > 2 or nl == 0 or (nl == 2 and e.calc_face_angle(0) < math.radians(30)):
                continue
            a, b = G(mw @ e.verts[0].co), G(mw @ e.verts[1].co)
            d = b - a
            if d.length == 0 or abs(d.y) / d.length < .8 or abs((a.x + b.x) / 2 - cx) < .3 * W:
                continue
            zc, yc = (a.z + b.z) / 2, (a.y + b.y) / 2
            # the MIDDLE of the door's height: lower down, the arch lips and
            # sill ends are vertical too (the Focus's first pass took one for
            # the front door's edge, 27 cm into the wing)
            # and nothing round the wheel arches: an arch lip is vertical where
            # it meets the door's height, and on the Polo it outweighed every
            # real shut line
            if zr < zc < zf and 1.0 * r < yc < 2.4 * r and \
                    all((yc - r) ** 2 + (zc - z) ** 2 > (1.3 * r) ** 2 for z in (zf, zr)):
                k = min(NB - 1, int((zc - zr) / wb * NB))
                hist[k] += d.length
                for yy in (a.y, b.y, yc):
                    hits[k][0 if (a.x + b.x) / 2 > cx else 1].add(min(NY - 1, max(0, int((yy - r) / (1.4 * r) * NY))))
        bm.free()
    # COVERAGE: how much of the door's height a line spans (6 bands, best
    # flank, neighbouring bins merged). A shut line runs the door's full
    # height; a handle or a badge only a band of it.
    cover = [max(len(set().union(*(hits[j][s] for j in range(max(0, k - 1), min(NB, k + 2))))) for s in (0, 1))
             for k in range(NB)]
    mean = sum(hist) / NB
    need = max(.1 * H, 1.5 * mean)
    zat = lambda k: zr + (k + .5) / NB * wb
    # A LINE is a bin covering at least 5 of the 6 height bands with at least
    # 60% of the strongest such bin's edge length in its search range. The
    # front door's leading edge is the MOST FORWARD line; the B-pillar is the
    # REARMOST line well behind it — so the handle at the back of the front
    # door (a full-height line on the Polo, stronger than either real edge)
    # loses both ways.
    def line(a, b, front):
        cand = [i for i in range(max(0, a), min(NB, b)) if cover[i] >= 5 and hist[i] >= need]
        if not cand:
            return None
        top_ = max(hist[i] for i in cand)
        cand = [i for i in cand if hist[i] >= .6 * top_]
        return max(cand) if front else min(cand)
    kf = line(int(.50 * NB), int(.85 * NB), True)
    kb = line(int(.20 * NB), (kf if kf is not None else int(.70 * NB)) - int(.22 * NB), False)
    F = zat(kf) if kf is not None else zf - .33 * wb
    Bp = zat(kb) if kb is not None else zf - .63 * wb
    Rr = zr + .045 * wb
    ev = {'front_edge': 'shut line' if kf is not None else 'proportion',
          'b_pillar': 'shut line' if kb is not None else 'proportion', 'rear_edge': 'proportion'}
    info['profile'] = [round(h, 2) for h in hist]       # rear axle -> front axle, for diagnosis
    info['cover'] = cover
    info.update(evidence=ev, front_edge_z=round(F, 3), b_pillar_z=round(Bp, 3), rear_edge_z=round(Rr, 3),
                peak_need=round(need, 3))
    if not (zr < Rr < Bp < F < zf) or F - Bp < .15 * wb or Bp - Rr < .15 * wb:
        info['result'] = 'door edges out of order — not cutting'
        return {}

    def near_arch(c):
        return any((c.y - r) ** 2 + (c.z - z) ** 2 < (1.35 * r) ** 2 for z in (zf, zr))

    def in_arch(c):
        # just inside the arch opening; the arch lip is a crease and stops the
        # growth anyway (1.12 r notched the Focus's rear doors)
        return any((c.y - r) ** 2 + (c.z - z) ** 2 < (1.03 * r) ** 2 for z in (zf, zr))

    # Each door skin is GROWN from a seed in its middle across smooth edges
    # only, so it stops at the creases that bound a real panel — the shut-line
    # groove, the belt crease, the sill, the arch lip — and the cut follows the
    # mesh's own edges. A face-by-face test against a plane left saw-teeth
    # wherever a big triangle crossed it (seen on the Focus's first render).
    # Where a side has no crease (no groove: the Polo) the growth runs to the
    # hard limit, and only then is it clamped at the line.
    # Growth is allowed well past each line; a line is applied only where the
    # growth ran on without meeting a panel edge. The Polo's door skins are
    # separate panels whose front edge sits 0.35 m ahead of the proportion
    # line, and a tight limit clamped them there with a saw-toothed edge.
    pad = .04 * wb
    nom = {'f': (Bp, F), 'r': (Rr, Bp)}
    grow = {'f': (Bp - pad, zf - .9 * r), 'r': (Rr - pad, F)}
    seed_z = {'f': zf - .48 * wb, 'r': zf - .80 * wb}
    if not Bp < seed_z['f'] < F:
        seed_z['f'] = (Bp + F) / 2
    if not Rr < seed_z['r'] < Bp:
        seed_z['r'] = (Rr + Bp) / 2
    groups, area, clamped, top = {}, {}, [], {}
    skin_x = {}
    for o in src:
        for i, c, n, a, m in faces(o):
            sd = 1 if c.x > cx else -1
            if GLASS_MAT.search(m) or sd * n.x <= .7 or not ysill < c.y < ytop:
                continue
            for d in ('f', 'r'):
                if abs(c.z - seed_z[d]) < .06 * wb and abs(c.y - 1.45 * r) < .35 * r:
                    skin_x[(sd, d)] = max(skin_x.get((sd, d), -1e9), sd * c.x)
    for o in src:
        mw = o.matrix_world
        n3 = mw.to_3x3().inverted().transposed()
        sc = abs(mw.to_3x3().determinant()) ** (2 / 3)
        mats = [sl.material.name if sl.material else '' for sl in o.material_slots]
        bm = bmesh.new()
        bm.from_mesh(o.data)
        tag = bm.faces.layers.int.new('orig')
        for f in bm.faces:
            f[tag] = f.index
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-5)    # weld for GROWTH only
        bm.faces.ensure_lookup_table()
        info_f = {}
        for f in bm.faces:
            n = G(n3 @ f.normal)
            if n.length:
                n.normalize()
            m = mats[f.material_index] if f.material_index < len(mats) else ''
            info_f[f.index] = (G(mw @ f.calc_center_median()), n, f.calc_area() * sc, m)
        for sd in (1, -1):
            side = 'l' if sd > 0 else 'r'
            for d, (z0, z1) in nom.items():
                pid = f'door_{d}{side}'
                g0, g1 = grow[d]

                paint = [None]

                def fits(f):
                    c, n, a, m = info_f[f.index]
                    return (not GLASS_MAT.search(m) and (paint[0] is None or m == paint[0])
                            and sd * (c.x - cx) > .25 * W and sd * n.x > .25
                            and ysill < c.y < ytop
                            and g0 < c.z < g1 and not in_arch(c)
                            # round an arch the flare turns toward the wheel; a
                            # door skin there stays flat to the side (the Polo's
                            # rear door ran on down its rear arch flare)
                            and (sd * n.x > .8 or not near_arch(c)))
                zm, ym = seed_z[d], 1.45 * r
                seeds = [f for f in bm.faces if fits(f) and sd * info_f[f.index][1].x > .7
                         and abs(info_f[f.index][0].z - zm) < .06 * wb
                         and abs(info_f[f.index][0].y - ym) < .35 * r]
                if not seeds:
                    continue
                # seeds only on the car's OUTER skin, measured over every mesh:
                # taken per mesh, a seat's outward-facing side was "the door"
                # of the seat mesh, and the Polo's doors carried seat bolsters
                seeds = [f for f in seeds if sd * info_f[f.index][0].x > skin_x.get((sd, d), 1e9) - .03 * W]
                if not seeds:
                    continue
                # the door's paint: the material covering most of the seed area
                ms = {}
                for f in seeds:
                    ms[info_f[f.index][3]] = ms.get(info_f[f.index][3], 0) + info_f[f.index][2]
                paint[0] = max(ms, key=ms.get)
                seeds = [f for f in seeds if info_f[f.index][3] == paint[0]]
                seen = {f.index for f in seeds}
                stk = list(seeds)
                while stk:
                    g = stk.pop()
                    for e in g.edges:
                        if len(e.link_faces) != 2 or e.calc_face_angle(0) > math.radians(ANG):
                            continue
                        for h in e.link_faces:
                            if h.index not in seen and fits(h):
                                seen.add(h.index)
                                stk.append(h)
                zs = [info_f[i][0].z for i in seen]
                # past the line it shares with the other door, or out to the
                # limit of growth: no panel edge there, so cut at the line
                lo_c = min(zs) < (z0 - .5 * pad if d == 'f' else g0 + .25 * pad)
                hi_c = max(zs) > (g1 - .25 * pad if d == 'f' else z1 + .5 * pad)
                if lo_c or hi_c:
                    clamped.append(f"{pid}{' rear' if lo_c else ''}{' front' if hi_c else ''}")
                keep = [i for i in seen if (not lo_c or info_f[i][0].z >= z0) and (not hi_c or info_f[i][0].z < z1)]
                if d == 'r' and lo_c:
                    # cut at a line with no panel edge: below the belt a rear
                    # door's edge follows the arch, so keep it off the arch
                    keep = [i for i in keep if (info_f[i][0].y - r) ** 2 + (info_f[i][0].z - zr) ** 2 > (1.25 * r) ** 2]
                for i in keep:
                    groups.setdefault(o, {}).setdefault(pid, set()).add(bm.faces[i][tag])
                    area[pid] = area.get(pid, 0) + info_f[i][2]
                    top[pid] = max(top.get(pid, -1e9), info_f[i][0].y)
        bm.free()
    # a face both doors grew into (no groove at the B-pillar) goes by the line
    for o, g in groups.items():
        for side in 'lr':
            f_, r_ = g.get('door_f' + side), g.get('door_r' + side)
            if f_ and r_ and f_ & r_:
                both = f_ & r_
                cz = {p.index: G(o.matrix_world @ p.center).z for p in o.data.polygons if p.index in both}
                f_ -= {i for i in both if cz[i] < Bp}
                r_ -= {i for i in both if cz[i] >= Bp}
    groups = {o: {p: sorted(f) for p, f in g.items()} for o, g in groups.items()}
    info['clamped_at_line'] = clamped
    info['skin_top'] = {p: round(y, 4) for p, y in top.items()}
    want = {'f': (F - Bp) * 1.6 * r, 'r': (Bp - Rr) * 1.6 * r}     # a door is ~1.6 wheel radii tall below the glass
    info['skin_area_share'] = {p: round(area.get(p, 0) / want[p[5]], 2)
                               for p in ('door_fl', 'door_rl', 'door_fr', 'door_rr')}
    # THE GATE. A door is cut only if it reads as a door: enough skin, not
    # absurdly much, below the glass line, and a clean outline. A failed door
    # stays welded shut — honest — rather than swinging a ragged slab.
    bad = {}
    for p_, sh in info['skin_area_share'].items():
        if sh < .4:
            bad[p_] = f'too little skin ({sh})'
        elif sh > 1.8:
            bad[p_] = f'too much skin ({sh}) — grew past the door'
        elif top.get(p_, 0) > lo.y + .78 * H:
            bad[p_] = 'reaches above the glass line'
        elif sh > 1.3 and sum(1 for c_ in clamped if c_.startswith(p_ + ' ')
                               and 'rear' in c_ and 'front' in c_):
            bad[p_] = f'no panel edge at either end and oversized ({sh}) — not a door'
    # a door and its mirror twin are cut together or not at all: one rear door
    # opening and the other welded shut is a broken car, not an honest one
    for p_ in list(bad):
        twin = p_[:-1] + ('r' if p_[-1] == 'l' else 'l')
        bad.setdefault(twin, f'its twin {p_} was refused')
    info['refused_doors'] = bad
    ok = [p_ for p_ in info['skin_area_share'] if p_ not in bad]
    if not {'door_fl', 'door_fr'} <= set(ok):
        info['result'] = f'too little door skin found ({info["skin_area_share"]}) — not cutting'
        return {}
    # each side window above a kept door goes with it, as a whole pane
    for o in gls:
        for c in _islands(o):
            b0, b1 = c[0]
            mid = (b0 + b1) / 2
            sd = 1 if mid.x > cx else -1
            if sd * (mid.x - cx) < .25 * W or b1.y < 1.6 * r or b1.z - b0.z > .6 * wb:
                continue
            d = 'f' if Bp <= mid.z < F + .03 * wb else 'r' if Rr <= mid.z < Bp else None
            pid = d and f"door_{d}{'l' if sd > 0 else 'r'}"
            if pid in ok:
                groups.setdefault(o, {}).setdefault(pid, []).extend(c[2])
    inner = bpy.data.materials.get('SB_door_inner') or bpy.data.materials.new('SB_door_inner')
    inner.use_nodes = True
    bsdf = inner.node_tree.nodes.get('Principled BSDF')
    bsdf.inputs['Base Color'].default_value = (0.045, 0.045, 0.05, 1)
    bsdf.inputs['Roughness'].default_value = 0.7
    out = {}
    for o, g in groups.items():
        todo = [(p, f) for p, f in g.items() if p in ok]
        if not todo:
            continue
        for (pid, _), new in zip(todo, _lift_many(o, [f for _, f in todo])):
            new.name = 'door_cut_' + pid[5:]
            new['sb_chain'] = new.name
            if o in src:
                _door_card(new, inner, 1 if pid[-1] == 'l' else -1, .025 * W)
            out.setdefault(pid, []).append(new)
    info['result'] = f"cut {len(out)} door(s) from the body: {sorted(out)}"
    info['faces'] = {p: sum(len(x.data.polygons) for x in os_) for p, os_ in out.items()}
    return out


def _door_card(o, mat, sd, t):
    """Back a cut door skin with a dark inner panel `t` inboard, facing in, so
    the open door is not a hollow sheet seen from behind."""
    o.data.materials.append(mat)
    mi = len(o.data.materials) - 1
    off = o.matrix_world.to_3x3().inverted() @ B(Vector((-sd * t, 0, 0)))
    bm = bmesh.new()
    bm.from_mesh(o.data)
    vmap = {v: bm.verts.new(v.co + off) for v in list(bm.verts)}
    for f in list(bm.faces):
        try:
            nf = bm.faces.new([vmap[v] for v in reversed(f.verts)])
            nf.material_index = mi
        except ValueError:
            pass
    bm.to_mesh(o.data)
    bm.free()


def _adopt_into_doors(parts, rep):
    """For doors found as islands: the glass, handles, trim and door card are
    loose pieces of OTHER meshes (all windows are one Window mesh on the RS6).
    Any island lying wholly inside a side's door box travels with the door.
    Where that side's doors were split at a shut line, the same cut divides
    the adopted pieces too — a chrome strip running along both windows goes
    half with each door rather than staying behind floating."""
    info = rep.setdefault('door_finder', {})
    moved = 0
    for side in ('l', 'r'):
        dps = [p for p in ('door_f' + side, 'door_r' + side) if p in parts]
        if not dps:
            continue
        boxes = {p: bbox([v for o in parts[p] for v in wv(o)]) for p in dps}
        b0 = Vector([min(boxes[p][0][i] for p in dps) for i in range(3)])
        b1 = Vector([max(boxes[p][1][i] for p in dps) for i in range(3)])
        cutter = bool(rep.get('door_cutter', {}).get('faces'))
        hubs = []
        for k in ('wheel_fl', 'wheel_fr', 'wheel_rl', 'wheel_rr'):
            if parts.get(k):
                w0, w1 = bbox([v for o in parts[k] for v in wv(o)])
                hubs.append(((w0.z + w1.z) / 2, (w1.y - w0.y) / 2))
        cut = info.get(f'split_{side}', {}).get('cut_z')
        m = .02
        if cutter:
            allv = [v for os_ in parts.values() for o in os_ if len(o.data.vertices) for v in wv(o)]
            c0, c1 = bbox(allv)
            Wc, roof = c1.x - c0.x, c1.y - .02 * (c1.y - c0.y)
            sx = 1 if side == 'l' else -1
            # the door card plane: the innermost of the door's own pieces
            outer = {q: max(abs(v.x) for o in parts[q] for v in wv(o)) for q in dps}
            tops = rep['door_cutter'].get('skin_top', {})
        for other in ('glazing', 'body', 'cabin'):
            for o in list(parts.get(other, [])):
                if len(o.data.polygons) < 2:
                    continue
                mw = o.matrix_world
                grp = {p: [] for p in dps}
                for c in _islands(o):
                    cb0, cb1 = c[0]
                    if cutter:
                        # A CUT door takes everything in its APERTURE: centred in
                        # the door's length, sill to roof rail, in the outer slab
                        # of the car. The window frame, glass and belt moulding
                        # are loose pieces that overhang the shut line by a few
                        # cm; a must-fit-in-the-box rule left the Polo's on the
                        # body as a bar floating across the opening.
                        mid = (cb0 + cb1) / 2
                        p = None
                        for q in dps:
                            q0, q1 = boxes[q]
                            ln = q1.z - q0.z
                            if not (q0.z - m <= mid.z <= q1.z + m and cb0.z >= q0.z - .12 * ln
                                    and cb1.z <= q1.z + .12 * ln and cb0.y >= q0.y - m and cb1.y <= roof):
                                continue
                            # outer slab: not inboard of the door card by more
                            # than a little, and nothing crossing the car
                            inb = min(abs(cb0.x), abs(cb1.x))
                            if sx * cb0.x < 0 or inb < outer[q] - .2 * Wc:
                                continue
                            # DEEP and below the glass, a piece must be a door
                            # card: thin across the car and facing INTO the cabin.
                            # The Polo's card sits 24 cm inside the skin, as deep
                            # as the outward-facing side of a seat.
                            # ABOVE the glass line a door takes its glass, its
                            # mirror (standing proud of the skin) or a frame long
                            # enough to be the frame — never one upright of a
                            # window surround that runs along both doors: alone it
                            # stands off the open door like a fin (the Focus)
                            if (other != 'glazing' and cb0.y >= tops.get(q, 1e9) - m
                                    and cb1.z - cb0.z < .4 * ln
                                    and max(abs(cb0.x), abs(cb1.x)) <= outer[q] + .03 * Wc):
                                continue
                            if inb < outer[q] - .08 * Wc and cb0.y < tops.get(q, 1e9) - m:
                                if cb1.x - cb0.x > .12 * Wc or facing(o, c[2], sx) > -.1:
                                    continue
                            p = q
                            break
                        # never anything round a wheel: brake shields and arch
                        # liners sit inside a rear door's box (the Polo's rode off)
                        if p and not any((mid.y - wr_) ** 2 + (mid.z - wz_) ** 2 < (1.35 * wr_) ** 2
                                         for wz_, wr_ in hubs):
                            grp[p] += c[2]
                        continue
                    if not all(b0[i] - m <= cb0[i] and cb1[i] <= b1[i] + m for i in range(3)):
                        continue
                    if cut is not None and len(dps) == 2:
                        for i in c[2]:
                            z = G(mw @ o.data.polygons[i].center).z
                            grp['door_f' + side if z > cut else 'door_r' + side].append(i)
                    else:
                        cz = (cb0.z + cb1.z) / 2
                        p = min(dps, key=lambda q: abs((boxes[q][0].z + boxes[q][1].z) / 2 - cz))
                        grp[p] += c[2]
                todo = [(p, g) for p, g in grp.items() if g]
                if not todo:
                    continue
                if len(todo) == 1 and len(todo[0][1]) >= len(o.data.polygons):
                    # the whole object is the door's: move it as it is
                    parts[other].remove(o)
                    parts[todo[0][0]].append(o)
                    moved += len(todo[0][1])
                    continue
                if sum(len(g) for _, g in todo) >= len(o.data.polygons) and not cutter:
                    continue
                for (p, g), new in zip(todo, _lift_many(o, [g for _, g in todo])):
                    new['sb_chain'] = o['sb_chain']
                    parts[p].append(new)
                    moved += len(g)
    info['adopted_faces'] = moved


def facing(o, fidx, sx):
    """Area-weighted mean of a face set's normal across the car, signed so that
    + is outward on side `sx` (+1 left, -1 right) and - is into the cabin."""
    n3 = o.matrix_world.to_3x3().inverted().transposed()
    num = den = 0.0
    for i in fidx:
        p = o.data.polygons[i]
        n = G(n3 @ p.normal)
        if n.length:
            num += sx * n.normalized().x * p.area
            den += p.area
    return num / den if den else 0.0


def _lift_panels(parts, paint, lo, hi, rep):
    need = [p for p in _wanted(parts) if not parts.get(p)]
    if not (need and paint):
        return
    L, W, H = hi.z - lo.z, hi.x - lo.x, hi.y - lo.y
    for o in list(parts.get('body', [])):
        if not any(s.material is paint for s in o.material_slots):
            continue
        progress = True
        while need and progress:                    # re-read islands after every lift
            progress = False
            comps = _islands(o)
            for pid in list(need):
                # a bonnet or saloon boot lid faces UP; a hatch or van tailgate
                # stands near-vertical and faces BACK
                def where(c):
                    return ((c[0][1].x - c[0][0].x) > .6 * W and c[0][0].y > lo.y + .25 * H
                            and (c[0][1].z > hi.z - .15 * L if pid == 'panel_bonnet'
                                 else c[0][0].z < lo.z + .15 * L))
                cand = [c for c in comps if where(c)
                        and (abs(c[1]) > .55 if pid == 'panel_bonnet' else (abs(c[1]) > .55 or c[3] < -.55))]
                if not cand:
                    # FALLBACK ONLY: a panel modelled with thickness is a closed
                    # shell whose normals cancel (RS6 bonnet mean-up 0.0). Used
                    # first, this test let a SECOND piece qualify on the Peugeot
                    # 308 and the unique-candidate rule then refused its bonnet.
                    cand = [c for c in comps if where(c)
                            and (c[5] > .6 if pid == 'panel_bonnet' else c[5] + c[6] > .9)]
                rep.setdefault('island_candidates', {})[pid] = len(cand)
                if len(cand) == 1:
                    parts.setdefault(pid, []).append(_lift(o, cand[0][2]))
                    need.remove(pid)
                    rep.setdefault('lifted', {})[pid] = len(cand[0][2])
                    progress = True
                    break
        if not need:
            break


def _hinges(parts, island_doors=False):
    hinge = {}
    for pid in [k for k in parts if k.startswith('door_b')]:
        # barn door: vertical hinge on its OUTER edge, at the back face
        vs = [v for o in parts[pid] for v in wv(o)]
        b0, b1 = bbox(vs)
        xs = sorted(abs(v.x) for v in vs)
        x = xs[int(.98 * (len(xs) - 1))]
        edge = [v for v in vs if abs(v.x) > x - .06]
        hinge[pid] = {'x': round(x if pid[-1] == 'l' else -x, 4), 'y': round((b0.y + b1.y) / 2, 4),
                      'z': round(sum(v.z for v in edge) / len(edge), 4)}
    for pid in [k for k in parts if k.startswith('door_') and k[5] in 'fr']:
        vs = [v for o in parts[pid] for v in wv(o)]
        b0, b1 = bbox(vs)
        edge = [v for v in vs if v.z > b1.z - .06]
        if island_doors:
            # an island door carries the inner pieces it adopted (door card,
            # trim); the last 6 cm can be ALL inner trim — the RS6's rear door
            # put its hinge 24 cm inboard that way. Use the front 15% instead,
            # so the outer skin is in the sample.
            edge = [v for v in vs if v.z > b1.z - .15 * (b1.z - b0.z)]
        xs = sorted(abs(v.x) for v in edge)
        x = xs[int((.95 if island_doors else .9) * (len(xs) - 1))]
        hinge[pid] = {'x': round(x if pid[-1] == 'l' else -x, 4), 'y': round((b0.y + b1.y) / 2, 4),
                      'z': round(b1.z, 4)}
    if parts.get('panel_bonnet'):
        vs = [v for o in parts['panel_bonnet'] for v in wv(o)]
        b0, b1 = bbox(vs)
        hinge['panel_bonnet'] = {'x': 0, 'y': round(max(v.y for v in vs if v.z < b0.z + .06), 4),
                                 'z': round(b0.z, 4)}
    if parts.get('tailgate'):
        vs = [v for o in parts['tailgate'] for v in wv(o)]
        b0, b1 = bbox(vs)
        hinge['tailgate'] = {'x': 0, 'y': round(max(v.y for v in vs if v.z > b1.z - .06), 4),
                             'z': round(b1.z, 4)}
    return hinge


def _motion(parts, height, rep, override=None):
    """Which doors SLIDE (and which are barn doors). A van's side door runs back
    along a rail; swinging it on a hinge would drive it through the body.

    Evidence, strongest first:
      1. `override` — a per-car ruling from overrides.json. Geometry cannot
         decide every car, and a person who has looked at it can.
      2. the file NAMES it sliding (`slide`, `sliding`).
      3. the VAN SIGNATURE, measured in WHEEL DIAMETERS so it survives the
         catalogue's scale spread: the rear side door is TALLER than the front
         door (>= 1.04x) and the vehicle is >= 2.6 wheel diameters tall.
         Calibrated on 25 converted cars: it catches the Vito (1.06x, 2.71)
         and fires on none of the 23 cars with hinged rear doors.

    WHAT IT CANNOT DO, measured: an MPV like the VW Sharan (sliding) and a
    Mazda 3 (hinged) are the SAME shape by every bounding-box ratio tried —
    rear door 1.77 vs 1.79 wheel diameters tall, vehicle 2.55 vs 2.52. So the
    Sharan needs an override. An earlier absolute rule (vehicle >= 1.75 m)
    slid the rear doors of a Micra and a Captur, because those files are
    modelled at ~1.25x real size: never judge this catalogue in metres.
    A sliding door moves OUT then BACK by most of its own length."""
    override = override or {}
    motion = {}
    for pid in ('door_bl', 'door_br'):
        if pid in parts:
            motion[pid] = {'type': 'barn', 'why': 'door across the back of the vehicle'}
    wd = []
    for k in ('wheel_fl', 'wheel_fr', 'wheel_rl', 'wheel_rr'):
        if k in parts:
            b0, b1 = bbox([v for o in parts[k] for v in wv(o)])
            wd.append(b1.y - b0.y)
    wd = sum(wd) / len(wd) if wd else 0

    def dh(k):
        b0, b1 = bbox([v for o in parts[k] for v in wv(o)])
        return b1.y - b0.y, b1.z - b0.z
    fh = [dh(k)[0] for k in ('door_fl', 'door_fr') if k in parts]
    fh = sum(fh) / len(fh) if fh else 0
    sig = {}
    for pid in ('door_rl', 'door_rr'):
        if pid not in parts:
            continue
        h, l = dh(pid)
        ratio = h / fh if fh else 0
        sig[pid] = {'rear_over_front': round(ratio, 3), 'height_in_wheels': round(height / wd, 3) if wd else 0}
        forced = override.get(pid)
        if forced:
            if forced == 'slide':
                motion[pid] = {'type': 'slide', 'out': 0.07, 'back': round(0.82 * l, 3), 'why': 'override'}
            continue
        named = any(SLIDE_NAME.search(o['sb_chain']) for o in parts[pid])
        van = wd and fh and ratio >= 1.04 and height / wd >= 2.6
        if named or van:
            motion[pid] = {'type': 'slide', 'out': 0.07, 'back': round(0.82 * l, 3),
                           'why': 'named sliding' if named else
                           f'van signature: rear door {ratio:.2f}x the front door, vehicle {height / wd:.2f} wheels tall'}
    rep['door_signature'] = sig
    return motion


# ═════════════════════════════════════════════════════════════════════════
def import_glb(path):
    """Import one glTF/GLB and return exactly the objects it created."""
    before = set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=path)
    bpy.context.view_layer.update()
    return [o for o in bpy.data.objects if o not in before]


def export_parts(parts, dst):
    """Export ONLY this car's parts, in glTF's Y-up frame."""
    objs = [o for os_ in parts.values() for o in os_]
    _select_only(objs)
    bpy.ops.export_scene.gltf(filepath=dst, export_format='GLB', use_selection=True,
                              export_normals=True, export_skins=False,
                              export_animations=False, export_apply=True)


def process_file(src, dst, report_path=None, override=None):
    """Import `src`, rig it, export `dst`. Returns (rep, parts). Raises Refused.
    The objects stay in the scene so a caller can add controls or save .blend.
    `override` is this car's entry from overrides.json, e.g.
    {"door_rl": "slide", "door_rr": "slide"}; "swing" forces a hinge."""
    rep = {'src': src.replace('\\', '/').rsplit('/', 1)[-1], 'rigger': VERSION}
    imported = import_glb(src)
    names = [o.name for o in imported]      # by NAME: a deleted object cannot be asked
    try:
        parts, hinge = convert(imported, rep, override)
        if override:
            rep['override'] = override
    except Refused as e:
        rep['refused'] = str(e)
        if report_path:
            json.dump(rep, open(report_path, 'w'), indent=1)
        _remove([bpy.data.objects[n] for n in names if n in bpy.data.objects])
        raise
    if dst:
        export_parts(parts, dst)
    if report_path:
        json.dump(rep, open(report_path, 'w'), indent=1)
    return rep, parts


def load_overrides(*paths):
    """Merge overrides.json files: the one packaged with the add-on first,
    then one sitting in the input folder, which wins. Keys are file stems."""
    out = {}
    for p in paths:
        if p and os.path.exists(p):
            for k, v in json.load(open(p)).items():
                if not k.startswith('_'):
                    out.setdefault(k, {}).update(v)
    return out


def purge_orphans():
    """Free meshes, materials and images no object uses any more, so a batch
    of a thousand cars does not grow Blender's memory without bound."""
    for coll in (bpy.data.meshes, bpy.data.materials, bpy.data.images,
                 bpy.data.armatures, bpy.data.actions, bpy.data.textures):
        for d in list(coll):
            if d.users == 0:
                coll.remove(d)
